const express = require('express');
const app = express();
const port = 4000;
const mysql = require('mysql2');

// Middleware para permitir solicitudes de origen cruzado
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', 'http://127.0.0.1:5500');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

app.use(express.json());

// Conexion de Base de Datos
const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "",
    database: "ferremasdb",
}).promise();

app.get('/api/products', async (req, res) => {
    try {
        const data = await pool.execute("SELECT id, nombre, marca, categoria, precio, descripcion, image_url, stock FROM products");
        res.status(200).json(data[0]); // Aquí devolvemos todos los productos
    } catch (err) {
        res.status(500).json({ message: err });
    }
});

app.get('/api/products/:id', async (req, res) => {
    const id = req.params.id;
    try {
        const data = await pool.execute("SELECT * FROM products WHERE id=?", [id]);
        const rows = data[0];

        if (rows.length === 0) {
            res.status(404).json();
        } else {
            res.status(200).json(rows[0]);
        }
    } catch (err) {
        res.status(500).json({ message: err });
    }
});

function isValidProduct(product) {
    let hasErrors = false;
    const errors = {};

    if (!product.nombre) {
        errors.nombre = "El nombre es requerido";
        hasErrors = true;
    }

    if (!product.marca) {
        errors.marca = "El nombre es requerido";
        hasErrors = true;
    }

    if (!product.categoria) {
        errors.categoria = "La categoria es requerida";
        hasErrors = true;
    }

    if (!product.precio || isNaN(product.precio)) {
        errors.precio = "El precio no es válido";
        hasErrors = true;
    }

    if (!product.descripcion) {
        errors.descripcion = "La descripcion es requerida";
        hasErrors = true;
    }

    return { hasErrors, errors };
}

app.post('/api/products', async (req, res) => {
    const product = req.body;

    try {
        const result = isValidProduct(product);

        if (result.hasErrors) {
            res.status(400).json(result.errors);
            return;
        }

        // Insertar nuevo producto en la base de datos
        const created_at = new Date().toISOString();
        let sql = "INSERT INTO products (nombre, marca, categoria, precio, descripcion, imagen, stock, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        let values = [product.nombre, product.marca, product.categoria, product.precio, product.descripcion, product.imagen, product.stock, created_at];
        let data = await pool.execute(sql, values);

        const id = data[0].insertId;

        data = await pool.execute("SELECT * FROM products WHERE id=?", [id]);

        res.status(200).json(data[0][0]);
    } catch (err) {
        res.status(500).json({ message: err });
    }
});

app.put('/api/products/:id', async (req, res) => {
    const productId = req.params.id;
    const { stock } = req.body;

    try {
        // Actualizar el stock del producto en la base de datos
        const [result] = await pool.execute('UPDATE products SET stock = ? WHERE id = ?', [stock, productId]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: 'El producto no se encontró' });
        }

        res.status(200).json({ message: 'Stock actualizado correctamente' });
    } catch (err) {
        console.error('Error al actualizar el stock del producto:', err);
        res.status(500).json({ message: 'Error interno del servidor' });
    }
});

app.delete('/api/products/:id', async (req, res) => {
    const id = req.params.id;

    try {
        const data = await pool.execute("DELETE FROM products WHERE id=?", [id]);

        if (data[0].affectedRows === 0) {
            res.status(404).json();
            return;
        }
    } catch (err) {
        res.status(500).json({ message: err });
    }
});

app.listen(port, () => {
    console.log("Server en port" + port);
});
