// Función para actualizar el stock en el servidor
function updateStock(productId, newStock) {
    fetch(`http://localhost:4000/api/products/${productId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ stock: newStock })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('No se pudo actualizar el stock del producto');
        }
        console.log("Stock actualizado correctamente:", productId, newStock);
    })
    .catch(error => console.error('Error al actualizar el stock del producto:', error));
}

// Carro
let cartIcon = document.querySelector('#cart-icon');
let cart = document.querySelector(".cart");
let closeCart = document.querySelector("#close-cart");
let buyButton = document.querySelector(".btn-buy");

// Abrir carro
cartIcon.onclick = () => {
    cart.classList.add("active");
};

// Cerrar carro
closeCart.onclick = () => {
    cart.classList.remove("active");
};

// Cart Working JS
if (document.readyState == "loading") {
    document.addEventListener("DOMContentLoaded", ready);
} else {
    ready();
}

// Función para obtener y mostrar productos
function ready(){
    obtenerProductos()
      .then(data => {
        mostrarProductosEnInterfaz(data);
      })
      .catch(error => console.error('Error al obtener la lista de productos:', error));
}

// Función para mostrar productos en la interfaz de usuario
function mostrarProductosEnInterfaz(productos) {
    const shopContent = document.querySelector('.shop-content');

    shopContent.innerHTML = '';

    productos.forEach(producto => {
        const productBox = document.createElement('div');
        productBox.classList.add('product-box');

        const productImg = document.createElement('img');
        productImg.src = producto.image_url; 
        productImg.alt = producto.nombre; 
        productImg.classList.add('product-img');
        productBox.appendChild(productImg);

        const productTitle = document.createElement('h2');
        productTitle.textContent = producto.nombre;
        productTitle.classList.add('product-title');
        productBox.appendChild(productTitle);

        const productBrand = document.createElement('p');
        productBrand.textContent = 'Marca: ' + producto.marca;
        productBox.appendChild(productBrand);

        const price = document.createElement('span');
        price.textContent = `$${producto.precio}`;
        price.classList.add('price');
        productBox.appendChild(price);
        
        const stock = document.createElement('p');
        stock.textContent = 'Stock: ' + producto.stock;
        productBox.appendChild(stock);

        const productDescription = document.createElement('p');
        productDescription.textContent = producto.descripcion;
        productBox.appendChild(productDescription);

        const addCartIcon = document.createElement('i');
        addCartIcon.classList.add('bx', 'bx-shopping-bag', 'add-cart');
        addCartIcon.addEventListener('click', () => {
            addProductToCart(producto.nombre, producto.precio, producto.image_url, producto.stock, producto.id);
        });
        productBox.appendChild(addCartIcon);

        shopContent.appendChild(productBox);
    });
}

// Función para obtener los productos desde la API
function obtenerProductos() {
    return fetch('http://localhost:4000/api/products')
           .then(response => response.json());
}

// Función para agregar productos al carrito
function addProductToCart(title, price, productImg, stock, productId){
    var cartShopBox = document.createElement("div");
    cartShopBox.classList.add("cart-box");
    
    var cartItems = document.querySelector(".cart-content");

    var cartBoxContent = `
        <img src="${productImg}" alt="" class="cart-img">
        <div class="detail-box">
            <div class="cart-product-title">${title}</div>
            <div class="cart-price">${price}</div>
            <input type="number" value="1" class="cart-quantity">
        </div>
        <!-- Remover del carro -->
        <i class='bx bxs-trash cart-remove'></i>`;
    
    cartShopBox.innerHTML = cartBoxContent;
    cartItems.appendChild(cartShopBox);

    cartShopBox
        .getElementsByClassName("cart-remove")[0]
        .addEventListener("click", removeCartItem);
    cartShopBox
        .getElementsByClassName("cart-quantity")[0]
        .addEventListener("change", quantityChanged);

    updateStock(productId, stock);

    updatetotal();
}

// Función para eliminar un elemento del carrito
function removeCartItem(event){
    var buttonClicked = event.target;
    buttonClicked.parentElement.remove();
    updatetotal();
}

// Función para cambiar la cantidad de un producto en el carrito
function quantityChanged(event) {
    var input = event.target;
    if (isNaN(input.value) || input.value <= 0) {
        input.value = 1;
    }
    updatetotal();
}

// Función para actualizar el total del carrito
function updatetotal(){
    var cartContent = document.getElementsByClassName("cart-content")[0];
    var cartBoxes = cartContent.getElementsByClassName("cart-box");
    var total = 0;
    for (var i = 0; i < cartBoxes.length; i++){
        var cartBox = cartBoxes[i];
        var priceElement = cartBox.getElementsByClassName("cart-price")[0];
        var quantityElement = cartBox.getElementsByClassName("cart-quantity")[0];
        var price = parseFloat(priceElement.innerText.replace("$", ""));
        var quantity = quantityElement.value;
        total = total + (price * quantity);
    }
    total = Math.round(total * 100) / 100;
    document.getElementsByClassName('total-price')[0].innerText = "$" + total;
}

// Asignar evento de clic al botón "Comprar ahora"
buyButton.addEventListener("click", buyButtonClicked);

// Función para procesar la acción de hacer clic en "Comprar ahora"
function buyButtonClicked() {
    var cartContent = document.querySelector(".cart-content");

    // Verificar si hay elementos en el carrito
    if (cartContent.children.length === 0) {
        alert("El carrito está vacío. No se puede procesar la compra.");
        return; // Salir de la función si el carrito está vacío
    }

    // Procesar la compra
    alert("Su pedido está realizado");

    // Limpiar el carrito
    while (cartContent.hasChildNodes()) {
        cartContent.removeChild(cartContent.firstChild);
    }

    updatetotal();

    // Llamar a la función updateStock para reducir el stock de todos los productos comprados
    var cartBoxes = document.querySelectorAll(".cart-box");
    cartBoxes.forEach((cartBox) => {
        var productId = cartBox.getAttribute("data-product-id");
        var productStock = parseInt(
            cartBox.querySelector(".cart-quantity").value
        );
        console.log(
            "Producto ID:",
            productId,
            "Stock:",
            productStock
        ); // Verificar ID y stock en la consola
        updateStock(productId, productStock);
    });
}
